import React, { useState } from "react";
import { Icon } from "./Icon";
import { PostHeader } from "./PostHeader";

export const PostBody = ()=>{

    const [shiftOptions,setShift] = useState()
    window.addEventListener('resize',()=>{
        if(window.innerWidth <= 520)
            setShift(true)
        else
            setShift(false)
    })

    const [form, setForm] = useState({message:"We are interested in your skills"})
    const [showForm, setShow] = useState(false)
    return (
        <div className="row_center fillup pd_sm mg_v_md">
            <div>
                {shiftOptions && <SideActions />}
                <PostHeader/>
                <div>
                    <img src="/images/sample.png" className="w_100 obj_fit br_sm max_700"/>
                </div> 
                <br></br>
                <p>Planet Illustration for Galactic Jobs Hero section</p>  
                <div id="hireme"  className="mg_v_md">
                    <div className="winged">
                        <img className="round_70 obj_fit" src="/images/sample.png" />
                    </div>
                </div>    
                <div className="col_center">
                    <h5>Lahari</h5>
                    <p className="mg_sm">Do you need Illustration, logo or other designs?</p>
                    <button  onClick={()=>setShow(prev => !prev)} className="btn btn-primary mg_sm"> <i className={"fas mg_r_xs "+(showForm ? "fa-xmark": "fa-envelope")}></i> {showForm ? "Close": "Hire Me"}</button>
                    
                </div>
                {
                    showForm &&
                    <div>
                        <textarea name="message" value={form.message} placeholder="please type a custom message" className="w_100 bg-light slideDown" />
                        <form method="POST" action={"mailto:laharimaddipati1@gmail.com? &subject= We are interested in you &body= "+form.message} enctype="multipart/form-data" className="row_right">
                            <button type="submit"  className="btn btn-sm btn-primary">Send</button>
                        </form>
                    </div>   
                }
            </div>
        </div>
    )
}

export const SideActions = () =>{

    const [showOptions, setShow] = useState("")

    return (
        <div className="col_top no_wrap mg_t_lg shift">
            <div onClick={()=>setShow(prev => prev==="slideDown"? "slideUp": "slideDown")}>
                <Icon icon="fas fa-ellipsis sm-2 pd_xs mg_sm" bd />
            </div>
            
            <div className={"col_top shift hide "+showOptions}>
                <Icon link="https://www.linkedin.com/in/laharim/" icon="fab fa-linkedin text-primary sm-2 pd_xs mg_sm" bd />
                <Icon icon="fab fa-square-facebook sm-2 pd_xs mg_sm text_dim" bd />
                <Icon icon="fab fa-instagram sm-2 pd_xs mg_sm text_dim" bd />
                <Icon icon="fas fa-share-nodes sm-2 pd_xs mg_sm text_dim" bd />
            </div>
          
        </div>
    )
}