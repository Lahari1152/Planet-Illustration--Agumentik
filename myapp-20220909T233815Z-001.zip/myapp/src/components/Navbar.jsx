import React from "react";

export const Navbar = () => {

    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
  <a className="navbar-brand" href="#">dribbble</a>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>

  <div className="collapse navbar-collapse" id="navbarSupportedContent">
    <ul className="navbar-nav mr-auto sm ">
      <li className="nav-item active">
        <a className="nav-link text_green" href="#">Inspiration <span className="sr-only">(current)</span></a>
      </li>
      <li className="nav-item active">
        <a className="nav-link text_darkish" href="#">Find Work <span className="sr-only">(current)</span></a>
      </li>
      <li className="nav-item active">
        <a className="nav-link text_darkish" href="#">Learn Design <span className="sr-only">(current)</span></a>
      </li>
      <li className="nav-item active">
        <a className="nav-link text_darkish" href="#">Go Pro <span className="sr-only">(current)</span></a>
      </li>
      <li className="nav-item active">
        <a className="nav-link text_darkish" href="#">Design Files <span className="sr-only">(current)</span></a>
      </li>
      <li className="nav-item active">
        <a className="nav-link text_darkish" href="#">Hire Designers <span className="sr-only">(current)</span></a>
      </li>
    </ul>
    <form className="form-inline my-2 my-lg-0">
      <i className="fa-solid fa-magnifying-glass text_dim mg_r_sm"></i>
      <button className="btn btn-light  my-2 my-sm-0 text_dim  mg_r_sm" type="submit">Sign in</button>
      <button className="btn btn-primary my-2 my-sm-0" type="submit">Share my work</button>
    </form>
  </div>
</nav>
    )

}