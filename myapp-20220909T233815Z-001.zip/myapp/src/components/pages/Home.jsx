import React,{useState} from "react";
import {Navbar} from '../../components/Navbar';
import {PostBody, SideActions} from '../../components/PostBody';
import {Footer} from "../../components/Footer";
export const Home = () => {
    const [shiftOptions,setShift] = useState()
    window.addEventListener('resize',()=>{
        if(window.innerWidth > 520)
            setShift(true)
        else
            setShift(false)
    })
    return (
        <div>
            <Navbar />
            <div className="row_between wrap_rev">
                <PostBody/>
                {shiftOptions && <SideActions/>}
            </div>
            <Footer />
        </div>
    )

}