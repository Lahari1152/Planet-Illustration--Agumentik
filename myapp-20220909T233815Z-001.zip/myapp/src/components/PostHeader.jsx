import React from "react";

export const PostHeader = () => {

    return(
        <div className="row_between w_100 max_700 pd_v_sm mg_b_md">
            <div className="row_left">
                <div className="mg_r_md">
                    <img src="/images/sample.png" className="round_50" />
                </div>
                <div style={{alignItems:"flex-start"}} className="col_center pd_v_xs">
                    <div>
                        <h6 style={{textAlign:"left"}}>Planet Illustration</h6>
                    </div>
                    <div>
                        <p style={{textAlign:"left"}}>
                            <a>Lahari </a>
                            <i style={{fontSize:"5px"}} className="fas fa-circle mg_h_xs"></i>
                            <a>Follow</a>
                            <i style={{fontSize:"5px"}} className="fas fa-circle mg_h_xs"></i>
                            <a href="#hireme" className="text_action">Hire Me</a>
                        </p>
                    </div>
                    
                </div>
            </div>
            <div className="row_right">
                <button className="btn btn-light br_xs mg_r_sm text_dark">Save</button>
                <button className="btn btn-primary br_xs"><i className="fas fa-heart mg_r_sm"></i>Like</button>
            </div>
        </div>
    )

}