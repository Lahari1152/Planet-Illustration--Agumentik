import React from "react";

export const Icon = (props) => {
    return (
        <div className="cp" onClick={()=>{ props.link && window.open(props.link)}}>
        <i className={props.icon+" "+(props.bd && "outline br_xs")}>
        </i>
        </div>

    )
}