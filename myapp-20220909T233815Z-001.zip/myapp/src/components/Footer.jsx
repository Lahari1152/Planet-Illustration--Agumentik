import React from "react";
import { Icon } from "./Icon";

export const Footer = () => {
    return (
        <div className="bg-light pd_h_md pd_v_lg">

        <div className="container">
            <div style={{alignItems:"flex-start"}} className="col_center">
                <h3 className="text_amber mg_b_md">Dribbble</h3>
                <p>Dribbble is the world’s leading <br/> 
                    community for creatives to share, grow,<br/>
                    and get hired.
                </p>
                <div className="row_left sm-2 mg_v_md">
                <div className={"row_left"}>
                <Icon link="https://www.linkedin.com/in/laharim/" icon="fab fa-linkedin text-primary sm-2 pd_v_xs pd_r_xs mg_r_sm" />
                <Icon icon="fab fa-square-facebook sm-2 pd_xs mg_r_sm text_dim"  />
                <Icon icon="fab fa-instagram sm-2 pd_xs mg_r_sm text_dim" />
                <Icon icon="fas fa-share-nodes sm-2 pd_xs mg_r_sm text_dim" />
            </div>
                </div>
            </div>
            <div className="row">
            <div className="col-6 col-md-4 col-lg-3">
                <FooterCol data={footer_data[0]}/>
            </div>
            <div className="col-6 col-md-4 col-lg-3">
                <FooterCol data={footer_data[1]}/>
            </div>
            <div className="col-6 col-md-4 col-lg-3">
                <FooterCol data={footer_data[2]}/>
            </div>
            <div className="col-6 col-md-4 col-lg-3">
                <FooterCol data={footer_data[3]}/>
            </div>
            <div className="col-6 col-md-4 col-lg-3">
                <FooterCol data={footer_data[4]}/>
            </div>
            </div>
        </div>
        </div>
    )
}

const footer_data = [
    [
        {
            title:"For Designers",
            links:["Go Pro!", "Explore design work","Design Blog","Overtime podcast","Playoffs","Weekly Warm-Up","Code of Conduct"]
        }
    ],
    
    [
        {
            title:"Hire designers",
            links:["Post a job opening", "Post a freelance project","Search for designers"]
        },
        {
            title:"Brands",
            links:["Advertise with us"]
        }
    ],
    [
        {
            title:"Company",
            links:["About", "Careers","Support","Media Kit","Testimonials","API","Terms of service","Privacy policy","Cookie policy"]
        }
    ],
    [
        {
            title:"Directories",
            links:["Design jobs", "Designers for hire","Freelance designers for hire","Tags","Places"]
        },
        {
            title:"Design assets",
            links:["Creative Market", "Fontspring","Font Squirrel"]
        }
    ],
    [
        {
            title:"Design Resources",
            links:["Freelancing", "Design Hiring","Design Portfolio","Design Education","Creative Process","Design Industry Trends"]
        }
    ]
]

const FooterCol = (props) =>{
    const content = props.data
    return (
        <div className="col_top pd_r_sm">
            {
                content.map((item, index)=>{
                    return(
                        <>
                            <h6 className="mg_v_sm">{item.title}</h6>
                            {item.links.map((link, index)=>{
                                return(
                                        <p style={{cursor: "pointer"}} className="mg_v_mn sm">{link}</p>
                                    )
                                }) 
                            }                           
                        </>   
                    )

                })
            }
            <br/>
        </div>
    )
}